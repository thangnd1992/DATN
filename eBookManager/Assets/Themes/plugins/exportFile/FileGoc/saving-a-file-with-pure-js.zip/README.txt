A Pen created at CodePen.io. You can find this one at http://codepen.io/davidelrizzo/pen/cxsGb.

 Save a file using the HTML5 W3C saveAs() with JS fallback.